module.exports = {
    federation: {
        facebook: {
            clientId: '381497245811143',
            secretId: '18fd70920e18df4beea77dee6aa713d3', 
            callbackUrl: '/auth/login/facebook/callback' //페이스북에서 보내주는 url
        }
    }
};