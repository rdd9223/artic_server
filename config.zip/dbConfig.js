const mysql = require('promise-mysql');
const config = { 
    host: 'artic.cvvhkxkqobt2.ap-northeast-2.rds.amazonaws.com',
    port: 3306,
    user: 'rdd9223',
    password: 'artic1234',
    database: 'artic',
}
module.exports =  mysql.createPool(config); 