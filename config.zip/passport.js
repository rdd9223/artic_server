const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const FacebookStrategy = require('passport-facebook').Strategy;

const db = require('../module/pool');
const secret_config = require('./secret');
const responseMessage = require('../module/utils/responseMessage');

module.exports = () => {

    passport.serializeUser((user, done) => { // Strategy 성공 시 호출됨
        //사용자의 정보(user)가 세션에 저장
        done(null, user); // 여기의 user가 deserializeUser의 첫 번째 매개변수로 이동
    });

    passport.deserializeUser((user, done) => { // 매개변수 user는 serializeUser의 done의 인자 user를 받은 것
        //로그인에 성공하게 되면 Session정보를 저장을 완료했기에 이제 페이시 접근 시마다 사용자 정보를 갖게 Session에 갖게
        done(null, user);
    });

        //로컬 로그인 전략
        passport.use(new LocalStrategy({ // local login 전략
            //어떤 필드(key 값)로부터 아이디와 비밀번호를 전달받을 지 설정하는 옵션
            usernameField: 'id', //req.body.id
            passwordField: 'pw', //req.body.pw
            session: true, // 세션에 저장 여부
            passReqToCallback: false,   //req 객체를 콜백함수에 넘길지 여부. true로 하면 콜백함수의 인자가  (req, id, pw, done) 이
        }, async (id, pw, done) => { //done 이 실행되면 passport.serializeUser
            //실제 사용자 인증
            const findUserQuery = `SELECT * FROM user WHERE user_id = ${id}`;
            const findUserResult = await db.queryParam_None(findUserQuery);
    
            if (!findUserResult) {
                return done(null, false, { message: 'DB 에러' });
            } else if (findUserResult.length == 1) {
                if (findUserResult[0].pw == pw) {
                    return done(null, findUserResult[0]);
                } else {
                    return done(null, false, { message: 'ID 혹은 비밀번호가 틀렸습니다' });
                }
            } else {
                return done(null, false, { message: 'ID 혹은 비밀번호가 틀렸습니다' });
    
            }
        }));

    passport.use(new FacebookStrategy({
        clientID: secret_config.federation.facebook.clientId,
        clientSecret: secret_config.federation.facebook.secretId,
        callbackURL: secret_config.federation.facebook.callbackUrl,
        profileFields: ['id', 'email', 'gender','displayName','photo']
    }, async (accessToken, refreshToken, profile, done) => {
        var _profile = profile;
        console.log('Facebook login info');
        console.info(_profile);

        try {
            await loginLogic({
                authType: 2,
                email: null,
                name: _profile.displayName,
                img: _profile.profileUrl,
                pw: null
            }, done);
        } catch (err) {
            console.log("Facebook Error => " + err);
            done(err);
        }
    }));


    async function loginLogic(info, done) {
        console.log('process : ' + info.authType);

        const chkUserQuery = 'SELECT * FROM user WHERE user_id = ?';
        const insertUserQuery = 'INSERT INTO user (user_id, user_pw, user_type, user_birth, user_name, salt) VALUES (?, ?, ?, ?, ?, ?)';

        const chkUserResult = await db.queryParam_Arr(chkUserQuery, [info.name]);

        if (!chkUserResult) {
            return done(null, false, {
                message: responseMessage.DB_ERROR
            });
        } else if (chkUserResult.length == 1) { //기존 유저 로그인처리
            done(null, {
                idx: chkUserResult[0].userIdx
            });
        } else { //신규 유저 회원가입
            const insertUserResult = await db.queryParam_Arr(insertUserQuery, [info.name, info.email, info.img, info.authType, info.pw]);

            if (!insertUserResult) {
                return done(null, false, {
                    message: responseMessage.DB_ERROR
                });
            } else {
                done(null, { //정상적으로 끝났을때 passport.serializeUser 감
                    idx: insertUserResult.insertId
                });
            }
        }
    }



}